function AutoZscan2ZP22()
clear
clc

NN = 50000; %���沽��de����
RootDir = '.\';
ResultSaveDir = strcat(RootDir, '\', 'fc_result');

Freq_begin = 1;
Freq_end = 250;
Freq_step = 1;

Freq_begin_H = 250;
Freq_end_H = 2490;

url_Lfile_fc0 = strcat(RootDir, 'Lfile_fc0.mat');
url_Lfile_fc1 = strcat(RootDir, 'Lfile_fc1.mat');
url_Hfile 	  = strcat(RootDir, 'Hfile_7.mat');

Data1 = load(url_Lfile_fc0);%��ƵF
Data2 = load(url_Lfile_fc1);%��ƵFC
Data3 = load(url_Hfile);%��Ƶ

ScanImpedance1(NN,Data1,Freq_begin,Freq_end,Freq_step);
ScanImpedance2(NN,Data2,Freq_begin,Freq_end,Freq_step);
ScanImpedance2plusV5(Freq_begin,Freq_end,Freq_step, ResultSaveDir);

U_I_Z_F_10hz(NN,Data3,Freq_begin_H,Freq_end_H);

%%%%%%%
clear all;
Data_L = load(['ZP3'  '.mat']);
Data_L = cell2mat(struct2cell(Data_L));
Data_H = load(['DATA_ZPD'  '.mat']);
Data_H = cell2mat(struct2cell(Data_H));

Data_freq = [Data_L(:,1);Data_H(:,1)];
Data_Mag = [Data_L(:,2);Data_H(:,2)];
Data_Pha = [Data_L(:,3);Data_H(:,3)];
figure
subplot(2,1,1);
plot(Data_freq,20*log10(Data_Mag));
xlabel('Ƶ��(Hz)');
ylabel('��ֵ(dB)');
subplot(2,1,2);
plot(Data_freq,Data_Pha);
xlabel('Ƶ��(Hz)');
ylabel('���(��)');


f_savefig(ResultSaveDir, 'Freq-coupling-result(1-2500Hz)', {'fig', 'emf', 'png'}, 300);
